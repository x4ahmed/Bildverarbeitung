function [newImg] = changeContrast(img,x)
%CHANGECONTRAST Summary of this function goes here
%   Detailed explanation goes here
    
    multiplicationFactor = ...;
    newImg = ...;
end