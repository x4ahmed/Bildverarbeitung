% Schachbrettmuster erstellen
img = checkerboard(64);

%% SUSAN
kSize = 5;
padSize = ...;

img_padded = ...;
resultImg = ...;

% Fenster läuft über Bild
for i = ...
   for j = ...
       
       centerVal = ...;
       counter = 0;
       
       for k = ...
           for l = ...
                % Zählen, wie viele Pixel innerhalb der Fensterumgebung gleichen Grauwert haben, 
                % wie Pixel in Fenstermitte
               if img_padded(...) == ...
                   counter = ...;
               end
           end
       end
       resultImg(...) = ...;
    end    
end

resultImg = resultImg(padSize+1:end-padSize,padSize+1:end-padSize);

%% Filterantwort wird mit Schwellenwert binarisiert
threshold = ...;

finalImg = ;

%% Ergebnisse zeigen
figure;
subplot(1,3,1);
imshow(mat2gray(img));
title('Original');
subplot(1,3,2);
imshow(mat2gray(resultImg));
title('Binärbild');
subplot(1,3,3);
imshow(mat2gray(finalImg));
title('Grauwertecken');

%% Ausdünnen
