function [img] = changeScale(img)
%CHANGESCALE Summary of this function goes here
%   Detailed explanation goes here

    img = double(img);
    img = ...;
    img = ...;
    img = ...;

end

