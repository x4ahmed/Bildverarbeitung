function [result1] = myGaussianFFT(img, kSize, sigma)

    %% Filtering with FFT

    % Kernel erstellen
    kernel = ...;

    % in Grauwertbild umwandlen, falls notwendig
    if ndims(img) > 2
        img = rgb2gray(img);
    end
    % auf werte zwischen 0 und 1 skalieren
    img = mat2gray(img);


    % Filtern
    disp('filtering in frequency domain...')

    % Zeit erfassen
    tic;

    %############################################
    % FFT des Bildes
    img_ft = ...;
    % fftshift 
    img_ft = ...;

    % FFT des Kernels
    kernel_ft = ...;
    % fftshift 
    kernel_ft = ...;

    % Filtern in Fourier Domain
    img_ft = ...;

    % reconstruction
    img_recon = ...;
    img_recon = ...;


    elapsed = toc;
    disp(['elapsed time FFT-version: ',num2str(elapsed)]);
    result1 = mat2gray(abs(img_recon));
