%% Aufgabe 3.2b

load mri;

% Größe von D anzeigen lassen
sizeD = ...

% Größe von map anzeigen lassen
sizeMap = ...

% maximalen Grauwert von D anzeigen lassen 
maxInt_D = max(D(:))

%%
% Axialbild extrahieren
h = 5;
newImg = D(:,:,:,h);

% Bild normalisieren
newImg = ...;

% FFT
img_fft = ...;

% FFTshift
img_fft_shifted = ...;

% amplitudenbild
ampl = ...;

% phasenbild
phase = ...;

% Bilder anzeigen;
figure;
subplot(1,3,1);
% Originalbild
imshow(newImg);

subplot(1,3,2);
% Log-Amplitudenbild
imshow(...;

subplot(1,3,3);
% Phasenbild
imshow(...;
