%% Aufgabe 2.1c
% Größen definieren
imgSize = [100,100];
squareSize = [30,30];

% leeres Bild mit obigen Dimensionen erstellen
newImg = ...;

% Grenzen des weißen Fensters ermitteln 
rowStart = ...;
rowEnd = ...;

colStart = ...;
colEnd = ...;

% Festerbereich im Bild auf 1 (weiß) setzen
newImg(...;

% Bild rotieren (45 grad)
newImg = imrotate(newImg, 45);

% Fast Fourier transformation
img_fft = ...;

% fftshift anwenden
img_fft_shifted = ...;

% amplitudenbild
ampl = ...;

% phasenbild
phase = ...;

% Bilder anzeigen;
figure;
subplot(1,3,1);
% Originalbild
imshow(newImg);

subplot(1,3,2);
% Log-Amplitudenbild
imshow(mat2gray(log(ampl+1)));

subplot(1,3,3);
% Phasenbild
imshow(mat2gray(phase));
