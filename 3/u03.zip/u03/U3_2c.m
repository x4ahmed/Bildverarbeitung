%% Aufgabe 3.2c

load mri;

% Größe von D anzeigen lassen
sizeD = ...

% Größe von map anzeigen lassen
sizeMap = ...

% maximalen Grauwert von D anzeigen lassen 
maxInt_D = max(D(:))

%%
% Axialbild extrahieren
h = 5;
newImg = D(:,:,:,h);

% Bild normalisieren
newImg = ...;

% FFT
img_fft = ...;

% FFTshift
img_fft_shifted = ...;

% amplitudenbild
ampl = ...;

% phasenbild
phase = ...;

% Bilder anzeigen;
figure;
subplot(1,3,1);
% Originalbild
imshow(newImg);

subplot(1,3,2);
% Log-Amplitudenbild
imshow(...;

subplot(1,3,3);
% Phasenbild
imshow(...;

%% Fouriertransformierte aus Amplituden und Phasenspektrum rekonstruieren
% Prinzipiell gilt die Formel: amplitude * exp(1i* phase)
img_ft_rec =  ifftshift(ampl) .* exp(1i*ifftshift(phase));

% ifft2
img_rec = ifft2(img_ft_rec);

% normalisieren
img_rec = mat2gray(abs(img_rec));

%% Fouriertransformierte nur aus Phasenspektrum rekonstruieren
img_ft_phase_only = ...;

% ifft2
img_phase_only = ...;

% normalisieren
img_phase_only = ...;

%% Fouriertransformierte nur aus Amplitudenspektrum rekonstruieren
img_ft_ampl_only = ...;

% ifft2
img_ampl_only = ...;

% normalisieren
img_ampl_only = ...;

%% Alles anzeigen
subplot(2,2,1);
imshow(newImg);
subplot(2,2,2);
imshow(img_rec);
subplot(2,2,3);
imshow(img_phase_only);
subplot(2,2,4);
imshow(img_ampl_only);
